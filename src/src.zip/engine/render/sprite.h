#pragma once
#pragma once
#include <SDL3/SDL_rect.h>   // SDL_FRect
#include <optional>          //  std::optional 表示可选的源矩形
#include <string>

namespace engine::render {

    
      // 表示要绘制的视觉精灵的数据。
     
      //包含纹理标识符、要绘制的纹理部分（源矩形）以及翻转状态。
    //  位置、缩放和旋转由外部（例如 SpriteComponent）标识。
     //渲染工作由 Renderer 类完成。（传入Sprite作为参数）
     
    class Sprite final {
    private:
        std::string texture_id_;                      // 纹理资源的标识符
        std::optional<SDL_FRect> source_rect_;        // 可选：要绘制的纹理部分
        bool is_flipped_ = false;                     // 是否水平翻转

    public:
        //创建一个无效对象
        Sprite() = default;
        /*
          构造一个精灵
           texture_id 纹理资源的标识符。不应为空。
           source_rect 可选的源矩形（SDL_FRect），定义要使用的纹理部分。如果为 std::nullopt，则使用整个纹理。
          is_flipped 是否水平翻转
         */
        Sprite
        (const std::string& texture_id,
            const std::optional<SDL_FRect>& source_rect = std::nullopt,
            bool is_flipped = false) : texture_id_(texture_id),
            source_rect_(source_rect),
            is_flipped_(is_flipped) {}
       
        //  getters and setters 
        const std::string& getTextureId() const { return texture_id_; }                                     // 获取纹理 ID
        const std::optional<SDL_FRect>& getSourceRect() const { return source_rect_; }                      // 获取源矩形 (如果使用整个纹理则为 std::nullopt)
        bool isFlipped() const { return is_flipped_; }                                                      // 获取是否水平翻转

        void setTextureId(const std::string& texture_id) { texture_id_ = texture_id; }                      // 设置纹理 ID
        void setSourceRect(const std::optional<SDL_FRect>& source_rect) { source_rect_ = source_rect; }     //设置源矩形 (如果使用整个纹理则为 std::nullopt)
        void setFlipped(bool flipped) { is_flipped_ = flipped; }                                            // 设置是否水平翻转

    };

} // namespace 